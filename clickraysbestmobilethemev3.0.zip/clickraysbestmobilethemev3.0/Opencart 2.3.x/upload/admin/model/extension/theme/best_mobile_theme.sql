-- Add mobile settings
DELETE FROM `setting` WHERE `code`= 'best_mobile_theme';
